# Codex result — r4 session-bound source lifetime

2026-10-31 JST. STATUS: success (bounded expiry-policy change, synthetic validation).
Branch codex/v01c20-edi-value-provenance; baseline18c563a. No main merge.
Runtime v0.1c38r4/package0.1.60. Follow-on INPUT task starts AFTER this push.

## Scope / evidence / safety

See analysis/V01C38R4_SESSION_LIFETIME.md and supplied r3 repeated-reversal
runtime analysis. Session2 three/session4 two completed reversals, then5s expiry;
no stale in those sessions, session1 separately10 stale pairs/max1385ms. Missing
video means no visual-release clock claim. This patch addresses total duration,
not earlier START or animation speed. Private raw evidence is not redistributed.

Changed native_source_override.cpp: remove normal now-entryMs>=5000 end only;
cap emitted actor observations256 and counter snapshots64 per session. Retention
validation continues past log caps. Existing heading64/movement40/plane64/stale16,
fixed ring1024 unchanged. No admission/reversal math/source target/store changes.
State reset only on genuine new session; no reversal entry-time/generation renewal.
Transition/helper/ownership/source-lifecycle code unchanged. Existing100ms native/
worker freshness, stale suspend/recovery, invalid owner/normal/code/Deinit/disable/
F8/HardClosed guards and A/B stack/caller/target checks remain. Reviewed per-update
and per-store checks have no5s certificate dependency. C52 remains FAIL, no new
watch/hook/input/animation/Position/movement writes. Shared tooling/SF untouched.

Independent4096-per-path write/attempt safety budgets are PRESERVED. Removing
total TIME expiry does not authorize unlimited stores or quota reset. These can
remain a practical long-session limit; changing them needs separate review.
Do not silently call that quota diagnostic-only. No in-game acceptance claimed.

Also changed native smoke fixture, version.hpp/info.json/README_TEST, package
manifest metadata, PROJECT_STATE/result and new analysis. Artifacts:
MSM2-WS-v0.1c38r4.zip, MSM2-WS-v0.1c38r4-source.zip,
MSM2-WS-v0.1c38r4.script.disabled, BUILD_MANIFEST.json. Prior r3 artifacts retained.

## Exact validation / expected / actual

Repository root with `export PATH=/workspace/toolchains/analysis-python/bin:$PATH`.
PASS labels/groups are not summed unique assertions; focused/native suites repeat
within portable/canonical commands.

| Command | Expected | Actual |
| --- | --- | --- |
| `bash source/tools/test_reversal_heading.sh` | same reversal timing/duration and12 focused groups | exit0; 12 PASS / 0 SKIP / 0 UNAVAILABLE; 0.76s |
| `bash source/tools/build_windows.sh` | Windows build/version checks | exit0; 0 PASS / 0 SKIP / 0 UNAVAILABLE; 38.74s |
| `bash source/tools/test.sh` | portable regressions including unchanged entry/reversal | exit0; 25 PASS / 0 SKIP / 0 UNAVAILABLE; 7.83s |
| `bash source/tools/smoke_windows.sh` | Windows/Wine smoke invariants | exit0; 7 PASS / 0 SKIP / 0 UNAVAILABLE; 11.79s |
| `bash source/tools/test_native_source.sh` | actual31.1s same-session owned A/B run with straight>5s, >=20 completed alternating turns, active>30s; caps/Deinit/closed-generation/new-session/disable plus existing stale/identity/code cases | exit0; 11 PASS / 0 SKIP / 0 UNAVAILABLE; 98.45s |
| `bash source/tools/test_hooks_windows.sh` | full canonical chain/counterexamples, no skip/bypass of prior native gates | exit0; 901 PASS / 5 SKIP / 17 UNAVAILABLE; 381.68s |
| `python source/tools/release.py` | version/script/export/import/package validation and both CRCs | exit0; 1 PASS / 0 SKIP / 0 UNAVAILABLE; 1.61s |

Long run uses actual wall clock with synthetic owned lifecycle events and real
MinHook fixture A/B source commits. No backdated source entry/per-reversal reset;
GetTickCount64 advances normally on16ms cadence. Original source entry/session/
generation asserted each iteration; path budgets unexhausted. This is NOT native
owner Windows or actual game proof. Existing real-position-watch regression is
retained, not a newly enabled game watch. No safety assertions removed.

`git diff --exit-code 18c563a -- source/include/Math/reversal_heading.hpp
source/include/Math/source_orientation.hpp source/include/NativeHooks/ownership_guards.hpp
source/src/NativeHooks/source_lifecycle.cpp source/tools/workspace.py environment`
returned0/empty: unchanged independent guards/heading/entry/shared code.
`git diff --check`, staged equivalent and final ZIP CRC/source member identity
checks pass. Packaging repeated only after docs update; binary tests not repeated
for report-only package changes. Nonfatal Wine winedevice warnings do not replace
exit-code checks. All required commands executed; no previous run counted as new.

## SKIP / UNAVAILABLE / owner / publication

Canonical5 optional private replay datasets SKIP (not redistributed); independent
synthetic wrong-hash/decoder/native regressions still execute.17 UNAVAILABLE:
c40 VCH2, c49 bridge6, c50 native identity7, c51 post-return2. Registration never
stands in for native dispatch/order evidence; counterexamples/refusals preserved.
BLOCKED0 for bounded lifetime change. Owner r4 game acceptance additionally
UNAVAILABLE (no owner PC/game run here). No human update/game procedure written.
No full-log request or new capture. No active install/deploy.

Read required AGENTS/manuals/runtime analyses and shared Wisdoms references;
local policy change is not an engine ownership fact. No other repository changed.
Publication commit and independent GitHub head/blob equality recorded after push;
only then continue docs/CODEX_INPUT_START.md separately. Five old untracked legacy
artifacts remain unstaged. Final exact runtime log name if owner later runs:
MSM2-WS-v0.1c38r4-YYYYMMDD-HHMMSS[-NN].log under MSM2-WS/logs (existing naming).

### Verified lifetime publication (before INPUT work)

Implementation e63afec169132aaeae36e3b5ec6b68c55dd6ba75, normal push18c563a->e63afec.
`python3 /tmp/ws-r4-publication.py` exit0: independent GitHub fetch into
/tmp/ws-steering-docs-publication, FETCH_HEAD/ls-remote/local head equal; all13
changed file blobs from18c563a equal local bytes. `python3 /tmp/ws-r4-final-audit.py`
PASS: protected helpers/guards/lifecycle/shared tooling unchanged, None time cap,
4096 write/100ms freshness metadata, script/DLL hash, both ZIP CRCs and runtime/
native-fixture source equality. Exact existing script log naming unchanged.
This record-only package refresh retains script/DLL bytes; no binary test rerun
needed for documentation. Final lifetime record head is preserved in subsequent
INPUT inventory result; separately verify final pushed head before starting it.
