from pathlib import Path
import hashlib,json,subprocess,re,zipfile,shutil,configparser
root=Path(__file__).resolve().parents[1]
header=(root/'include/version.hpp').read_text();label=re.search(r'versionLabel\[\]="([^"]+)"',header)[1];version=re.search(r'packageVersion\[\]="([^"]+)"',header)[1]
info=json.loads((root/'mod/info.json').read_text());assert info['version']==version and label in info['description']
out=root/'output'/('WallSprint_'+label);out.mkdir(parents=True,exist_ok=True)
readme=(root/'README_TEST.md').read_text();assert label in readme and version in readme;shutil.copy2(root/'README_TEST.md',out/'README_TEST.md')
binary=(root/'build/windows/WallSprint.dll').read_bytes();assert label.encode()+b'\0' in binary and version.encode()+b'\0' in binary
pe=subprocess.check_output(['objdump','-p',str(root/'build/windows/WallSprint.dll')],text=True);assert 'PE32+' in pe
for export in ['script_enable','script_disable']:assert re.search(r'\b'+export+r'\b',pe)
deps=re.findall(r'DLL Name: (\S+)',pe);assert {d.lower() for d in deps}<={'bcrypt.dll','version.dll','kernel32.dll','msvcrt.dll','user32.dll'}
assert 'WriteProcessMemory' not in pe
ini=configparser.ConfigParser();ini.read(root/'mod/WallSprint.ini')
assert ini.getint('WallSprint','WALLSPRINT_ENABLE')==1 and ini.getint('WallSprint','WALLSPRINT_NATIVE_SOURCE_OVERRIDE')==1
assert all(ini.getint('WallSprint','WALLSPRINT_'+k+'_WRITE')==0 for k in ['ORIENTATION','ADHESION','MOVEMENT'])
assert ini.getint('Diagnostics','ORIENTATION_WRITER_TRACE')==0 and ini.getint('Diagnostics','SOURCE_ARGUMENT_CAPTURE')==0
assert ini.getfloat('WallSprint','WALLSPRINT_ENTRY_DELAY')==.7 and ini.getfloat('WallSprint','WALLSPRINT_ROTATE_TIME')==.25
package=out/'WallSprint.script'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in [('info.json',(root/'mod/info.json').read_bytes()),('WallSprint.ini',(root/'mod/WallSprint.ini').read_bytes()),('WallSprint.dll',binary)]:
  entry=zipfile.ZipInfo(name,(2026,10,23,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,data)
with zipfile.ZipFile(package) as z:assert z.testzip() is None and z.read('WallSprint.dll')==binary and set(z.namelist())=={'info.json','WallSprint.ini','WallSprint.dll'}
required=['V01C7_RUNTIME_RESULT.md', 'V01C7_RESULT.md', 'HARD_KILL_ATTRIBUTION.md', 'V01C8_GATE.md', 'V01C6_RUNTIME_RESULT.md', 'V01C6_RESULT.md', 'TRANSIENT_FRESHNESS_RECOVERY.md', 'V01C7_GATE.md', 'V01B8_RUNTIME_RESULT.md', 'V01B8_RESULT.md', 'PATH_B_CALLER_DECODE.md', 'PATH_B_SOURCE_LAYOUT.md', 'PATH_B_STORE_MAP.md', 'V01B9_GATE.md', 'V01B9_RESULT.md', 'PATH_B_COMPACT3X3_PROOF.md', 'DUAL_SOURCE_RETENTION.md', 'V01C1_GATE.md', 'V01C1_RUNTIME_RESULT.md', 'V01C1_RESULT.md', 'PATH_B_PROOF_DECODER_FIX.md', 'V01C2_GATE.md', 'V01C2_RUNTIME_RESULT.md', 'V01C2_RESULT.md', 'THIRD_WRITER_TRACE.md', 'V01C3_GATE.md', 'V01C3_RUNTIME_RESULT.md', 'V01C3_RESULT.md', 'REAL_THREAD_ENUM_FIX.md', 'V01C4_GATE.md', 'V01C4_RUNTIME_RESULT.md', 'V01C4_RESULT.md', 'SOURCE_LIFECYCLE_CONTINUITY.md', 'V01C5_GATE.md', 'V01C5_RUNTIME_RESULT.md', 'V01C5_RESULT.md', 'PATH_A_POSITION_PROOF.md', 'PLANAR_ADHESION.md', 'V01C6_GATE.md']+['V01B5_RESULT.md','IMMEDIATE_RESET_TRACE.md','RESET_WRITER_CANDIDATES.md','V01B6_GATE.md','V01B6_RESULT.md','PREARMED_RESET_TRACE.md','COMMON_WRITER_RESET_CALLS.md','RESET_WRITER_VERIFICATION.md','V01B7_GATE.md','V01B7_RUNTIME_RESULT.md','V01B7_RESULT.md','RESET_COPY_WRITER_ANALYSIS.md','DUAL_SOURCE_OWNERSHIP.md','V01B8_GATE.md','V01B5_RESET_SUMMARY.json','V01B4_EVIDENCE_SUMMARY.json','sdk_sources.json']
# Source is complete for runtime/build. Private game captures are deliberately excluded.
source=out/'source';source.mkdir(exist_ok=True)
for directory in ['src','include','tools','mod','vendor']:
 for p in (root/directory).rglob('*'):
  relative=p.relative_to(root)
  if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or 'native_v01a7' in p.parts or 'orientation_v01b3' in p.parts:continue
  target=source/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for name in ['README.md','README_TEST.md','BUILD.md','WORKLOG.md','CMakeLists.txt','LICENSE.txt','THIRD_PARTY_NOTICES.md']:shutil.copy2(root/name,source/name)
docs=root.parent/'docs' if (root.parent/'docs').is_dir() else root/'docs'
if docs.is_dir():
 for name in ['DEV_RULES.md','PROJECT_STATE.md','CODEX_NEXT.md','CODEX_RESULT.md']:
  if (docs/name).exists():
   (source/'docs').mkdir(exist_ok=True);shutil.copy2(docs/name,source/'docs'/name)
agent=root.parent/'AGENTS.md' if (root.parent/'AGENTS.md').exists() else root/'AGENTS.md'
if agent.exists():shutil.copy2(agent,source/'AGENTS.md')
for name in required:
 assert (root/'analysis'/name).exists()
 for folder in [source/'analysis',out/'analysis']:
  folder.mkdir(exist_ok=True);shutil.copy2(root/'analysis'/name,folder/name)
for folder in [out/'config']:
 folder.mkdir(exist_ok=True)
 for p in (root/'mod/presets').glob('*.ini'):shutil.copy2(p,folder/p.name)
for p in source.rglob('*'):
 assert p.name not in ['ActorRelativeCamera.dll','SwingCore.dll','WalkOnWallsV1.stage','writer.hex','Entry.bin','Init.bin','Update.bin','Deinit.bin']
 assert 'extracted' not in p.parts and 'native_v01a7' not in p.parts and 'orientation_v01b3' not in p.parts
review=json.loads((root/'analysis/V01B4_EVIDENCE_SUMMARY.json').read_text());assert review['v01b4_pass'] and review['entries']==687 and review['source_up']['source_candidate_identified'] and not review['v01b5_game_verified']
manifest={
 'version':label,'package_version':version,'artifact':'WallSprint.script','sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'dll_sha256':hashlib.sha256(binary).hexdigest(),'imports':deps,'exports':['script_disable','script_enable'],
 'target_exe':'Spider-Man2.exe','target_version':'2.810.0.0','expected_exe_sha256':'c9b912eff96facb746a705ac8b0b83c29faa7bbe53d984a0c5eb45efd0b738c9',
 'native_stack_source_write_enabled':True,'source_range':'RDX+[0x00,0x30), current-thread verified caller-local source only','position_write':False,'direct_actor_transform_write':False,'camera_write':False,'physics_internal_write':False,'animation_write':False,'adhesion_write':False,'movement_write':False,'gravity_write':False,
 'writer':'RVA0x2CFC580,584bytes,known32byte AOB/prefix/unique match/runtime boundary/fullSHA3aae659545a606d36c0f9bf39eb773e09f1b091ff8ae139e72709c13688e6cd6',
 'caller':'RVA0x2CFC850,168bytes,return0x2CFC8F3,fullSHA88502996d39173bf38086e8ddafd9eff2875dada30717d1c9f4651324fbe3b3f',
 'native_hooks':'existing4lifecycle/common writer plus exact original-hash-authenticated reset-copy raw entry',
 'lifecycle':'existing verified Observer retained; small preserved-register native gate callback at existing4thunks for synchronous Init/Entry/Update/Deinit/generation/owner/thread/freshness',
 'critical_gates':['exactexe/hash','all4verified lifecycle/full original hashes','current4ownedpatches and writer-ownedpatch','caller168byte integrity','fresh native activeWallRun>=.70s; worker identity/freshness retained','same owner/generation/native thread','worker context<=100ms/nativeUpdate<=100ms','fresh existing read-only Hero accessor/Transform==RCX','R8null','TEB.StackLimit<=source,source64<=StackBase','source=originalWriterRSP+0x28,16aligned,PAGE_READWRITE','valid proper affine matrix','N398finite,length.95..1.05,abs(y)<=.20','kill inactive'],
 'orientation':'fixed entry basis/forward; projected F0,Right=Up cross Forward,Forward=Right cross Up; quaternion slerp0.25sec; no re-start/steering/corner',
 'normal_change_abort_dot':.995,'native_sample_max_age_ms':100,'worker_context_max_age_ms':100,'max_writes_per_session':4096,'max_override_seconds':5,'log_ring_records':1024,
 'write_helper':'currentthreadstack check,64byte expected reread,SEH48byte store,64byte full readback including untouched Position16; best-effort48byte rollback on failure, abort no directActor recovery',
 'stop':'F8 latched OFF/fullgame restart; nativeDeinit closes before original; wrongidentity/invalidnormal/stale/patchloss/overwrite/budget stops; no reentry in failed samegeneration',
 'overwrite_observation':'read-only nativePRE retention after shared transition; loss resets metric without suppressing valid exact source writes; >=20 distinct updates OR300ms after both commits',
 'unknown_game_function_calls':0,'fresh_Hero_lookup':'reuse existing verified read-only SDK getter; no new vendor file or typed writer signature','WriteProcessMemory_import':False,
 'reference_mod_code_or_assets_added':False,'new_SM2ScriptTemplate_vendor_files':0,'full_game_code_dumps_distributed':False,'private_fixture_replays':'optional SKIP if captures absent; independent synthetic tests execute',
 'v01b4_real_log_sha256':review['log_sha256'],'v01b4_source_matrix_verified':True,'v01b4_gate_pass':True,'v01b5_source_reaches_Actor_verified':True,'v01b5_retention_verified':False,'v01b5_actual_log_sha256':'b4cf534572e01d6369db6e9f950137d42061c0016ceb1195441b7f966786f4ab','v01b6_game_verified':False,'v01b7_reset_path_identified':True,'v01b8_game_verified':False,'RESET_WRITER_VERIFIED':True,'ORIENTATION_OWNERSHIP_VERIFIED':False,'v01b6_gate':'NOT_ADMITTED_OR_LATE_PER_PROJECT_STATE','v01b7_gate':'RESET_PATH_IDENTIFIED_PER_CHECKED_IN_RUNTIME_RESULT','v01b8_gate':'PENDING_ACTUAL_DUAL_SOURCE_ENTRY_AND_RETENTION_A_E','adhesion_next_phase_enabled':False,
 'prearmed_reset_trace':{'enabled_with_native_source':True,'trigger':'native verified Update at elapsed>=.60; common writer fallback','prearm_elapsed':.60,'source_override_elapsed':.70,'deadline_native_elapsed':1.50,'unchanged_Up_records_suppressed':True,'primary_first':True,'max_sessions':8,'max_events':256,'max_threads':1,'common_record_ring':1024,'callback_wait':False,'new_hook_targets':1,'abi':'existing raw entry tailjump unchanged','timing':'event snapshots last override QPC, PREARM_STATUS first_override required','all_current_Hero_callers':True,'invalid_source_interpreted':False,'reset_patch':False,'zero_events_prove_absence':False},
 'reset_copy_source':{'writer_rva':'0x2cfc3c0','end_rva':'0x2cfc57c','original_size':444,'original_sha256':'ee33ad96fb1834f9977621ea988f7667f0eb3e47166a7115ba262072ebc50196','caller_return_rva':'0x2cfc84b','original_auth_before_hook':True,'caller_auth':'accepted-exe runtime boundary + exact direct E8 destination + unchanged caller body','entry_ABI':'raw saved-state tailjump','source_provenance':'aligned readable affine64 within current-thread writable caller-local stack [entryRSP+0x28,entryRSP+0x400]','source_write_range':'[0x00,0x30)','position_bytes_unchanged':16,'shared_transition':True,'R8_R9':'raw preserved, no invented null requirement'},
 'validation':'ASan/UBSan portable; Windows warnings-as-errors; Wine ABI/20k/source/native/prearm/reset; two real independent MinHook sources share transition, same-update late coverage, >=20-update and >=300ms retention; second thunk clobber/AVX/FPU/return preservation; exact-copy hash denial; offline dual gate negatives; no cloud game PASS',
 'limitations':['b7 reset identity accepted from checked-in runtime summary; actual b8 source layout/ownership pending','primary-thread-only hardware coverage; all-caller entries are bounded','helper scheduling can miss prearm; first_override status=1 is required','native Init+1.10 deadline; OS scheduling may delay physical cleanup','Old Up is previous observation, not atomic instruction-before','unknown writer ABI/source remains unverified; post-store RIP/5ms observed sequence anchor need anchored offline decode','short already-admitted source commit may finish concurrently with F8','source rollback failure is reported without directActor repair','explicit A/E mapping/video/no crash/Position review required'],
 'source_directory':'source'
}
# c1 supersedes historical read-only Path B claims above.
manifest.update({
 'path_b_override':True,'path_b_characterization_active':True,'lock_free_shared_snapshot':True,
 'source_range':'Path A RDX+[0x00,0x30) padded orientation; Path B RDX+[0x00,0x24) compact3x3; current-thread verified caller-local stack only',
 'overwrite_observation':'bounded hardware Up watch after both source commits; retention requires dot>=.98 for >=20 distinct updates or >=300ms',
 'v01b8_game_verified':False,'v01b8_gate':'MEASURED_LAYOUT_REJECTION_ZERO_B_WRITES_RETENTION_FAILED',
 'v01b9_gate':'COMPACT_3X3_LAYOUT_AND_A_E_SEMANTICS_VERIFIED_FROM_CHECKED_IN_RUNTIME_RESULT','v01c1_gate':'ACTUAL_STARTUP_PROOF_FAILED_ZERO_SOURCE_WRITES','v01c2_gate':'REAL_A_B_SOURCE_AND_VISIBLE_ROTATION_PASS_RETENTION_FAILED_THIRD_RESET_UNCAPTURED',
 'PATH_B_FIELDS_VERIFIED':True,'PATH_B_WRITE_PERMISSION':True,'ORIENTATION_OWNERSHIP_VERIFIED':False,
 'validation':'Windows warnings-as-errors; ASan/UBSan portable; Wine ABI/MinHook, full-function compact-map decoder, lock-free A/B source overrides, 36-byte metadata boundary, row-scale preservation, lifecycle/identity/kill gates, dual retention and hardware reset continuation. Synthetic tests never game evidence.',
 'limitations':['Actual c5 full-WallRun orientation passed on A; c6 is Position read-only, pending whole-path/W/exclusive-effects proof and real plane telemetry','Coverage is a bounded eligible-thread snapshot; caps, foreign DR, drops and later-created threads may miss writes','Before Up is previous observation, not atomic pre-instruction','A short already-admitted guarded store may finish concurrently with F8','No adhesion or later milestone is enabled']})
manifest['reset_copy_source'].update({'source_provenance':'compact3x3 at exact entry RDX=RSP+0x28 in current-thread stack; anchored original full-function decode maps nine scalar rows to padded RCX rows','source_write_range':'[0x00,0x24)','shared_transition':True,'position_bytes_unchanged':'all bytes at and after +0x24 unchanged','path_b_override':True,'row_scale_preserved':True,'metadata_untouched':True,'original_capture':'private PATH_B_FUNCTION/PATH_B_CODE before hook; never redistributed'})
manifest['prearmed_reset_trace'].update({'continue_after_first_reset':True,'path_b_write':True,'entry_link':'own B entry/current-thread serial, session/generation/owner/target/caller/QPC<=5ms; anchored original decode required'})
manifest['path_b_layout']={'bytes_observed':128,'bytes_written':36,'max_sessions':8,'entries_per_session':128,'ring_records':256,'elapsed_window':[.60,1.50],'pointer_dereferences':0,'layout':'COMPACT3X3_PROVEN','unknown_layout_aborts_path_b':True,'unknown_layout_aborts_path_a':False}
manifest['startup_decoder']={'backend':'Capstone 5.0.6 x86-64, full ISA, static','upstream_archive_sha256':'240ebc834c51aae41ca9215d3190cc372fd132b9c5c8aa2d5f19ca0c325e28f9','skipdata':False,'runs_in_hot_hook':False,'writer_decoded_bytes':444,'caller_decoded_bytes':128,'recovered_pairs':9,'actual_byte_regression':'PASS: exact c1 failure reproduced; c2 proof and production installer passed with authenticated original inputs, no game code executed','failure_diagnostic_max_bytes':16,'full_function_capture_logging':False}
manifest['reset_copy_source']['caller_original_sha256']='1665a7a329a983101673f05ccd95bbf3d738c39099469b4acfd14344ec98a79d'
manifest['prearmed_reset_trace'].update({'max_threads':128,'max_events':512,'primary_only':False,'process_expand_elapsed':.85,'deadline_native_elapsed':1.50,'snapshot_scans':1,'late_thread_rescans':0})
manifest['third_writer_trace']={'diagnostic_only':True,'third_path_override':False,'watch_bytes':12,'range':'Transform+[0x10,0x1c)','hardware_slots':'DR0 8 bytes + DR1 4 bytes','process_thread_cap':128,'skipped_id_summary_cap':16,'foreign_enabled_slots_preserved':True,'saved_debug_state_restored':True,'PAGE_GUARD':False,'page_protection_changes':False,'direct_game_calls':False,'function_capture_max_bytes':16384,'raw_function_capture':'one selected function per session; private local runtime log only; never release ZIP','first_reset_once_per_session':True,'classification':['KNOWN_PATH_A','KNOWN_PATH_B','UNKNOWN_WRITER'],'independent_last_A_B_timestamps':True,'real_game_third_writer_verified':False}
manifest['v01c3_gate']='REAL_PRIMARY_WATCH_ALIVE_ZERO_PROCESS_ENUMERATION_NO_THIRD_WRITER_CAPTURE';manifest['v01c2_real_source_override_verified']=True
manifest['real_thread_enum_fix']={'expand_threshold_comparison':'>=850ms','same_production_enumerator_in_native_test':True,'expand_state_fields':['requested','attempted','completed','failed'],'enum_telemetry':['snapshot_created','thread32first_ok','entries_total','owner_pid_matches','win32_error_stage','win32_error_code'],'helper_stop_gate_named':True,'common_record_pressure_closes_watch':False,'event_pressure_closes_watch':False,'preexpand_event_limit':128,'expanded_reserved_events':384,'attempts':1,'rescans':0,'real_game_coverage_verified':False}
manifest['real_thread_enum_fix']['real_game_coverage_verified']=True
manifest['real_thread_enum_fix']['real_game_coverage_complete']=False
manifest['v01c4_gate']='REAL_ENUMERATION_AND_RETENTION_THRESHOLD_PASS_EARLY_LIFECYCLE_EXIT'
manifest['real_game_retention_threshold_verified']=True
manifest['real_game_lifecycle_wide_hold_verified']=False
manifest['source_lifecycle_continuity']={'reader_locks_native_events':False,'bounded_atomic_read_attempts':8,'actual_native_event_collision_fail_closed':True,'native_update_freshness_ms':100,'worker_publication_freshness_ms':100,'age_clock':'after token acquisition','synchronous_native_close_epoch_preserved':True,'same_failed_session_reentry':False,'exit_diagnostic_once_per_session':True,'verified_Deinit_summary':True,'diagnostic_watch_window_limits_source_ownership':False,'full_WallRun_real_game_verified':False}
manifest['v01c5_gate']='REAL_LIFECYCLE_WIDE_ORIENTATION_PASS_THROUGH_NATIVE_DEINIT'
manifest['real_game_lifecycle_wide_hold_verified']=True
manifest['ORIENTATION_OWNERSHIP_VERIFIED']=True
manifest['source_lifecycle_continuity']['full_WallRun_real_game_verified']=True
manifest['path_a_position_proof']={'admitted':False,'mode':'startup_candidate_inspection_only','original_writer_bytes':584,'original_caller_bytes':168,'original_before_owned_patch':True,'complete_decode_required':True,'candidate_access_cap':24,'control_edge_cap':16,'W_semantics':'unproven','whole_path_and_exclusive_effects':'unproven','runtime_source_provenance_records_per_session':2,'full_function_bytes_distributed':False,'position_store_implemented':False}
manifest['planar_adhesion']={'mode':'Position read-only','target_distance':0.5,'deadzone':0.01,'gain':0.25,'max_requested_step':0.02,'max_abs_error':0.35,'minimum_transition_t':1.0,'sample_interval_ms':100,'session_sample_cap':64,'normal_only_candidate':True,'actual_position_writes':False,'actual_max_step':0,'actual_max_tangent_delta':0,'source_Position_W_preserved':True,'after_error_semantics':'same unmodified observation; not a post-native measurement','session_summary':True,'real_game_telemetry_verified':False}
manifest['v01c7_gate']='POSITION_READ_ONLY_PENDING_WHOLE_PATH_W_EFFECTS_PROOF_AND_REAL_PLANE_TELEMETRY'
manifest['validation']='Windows warnings-as-errors for WallSprint; portable ASan/UBSan; full Wine hook/ABI/lifecycle/lock-free A-B/metadata/retention suites; actual hash-verified writer444/caller128 reproduces old c1 failure and passes full Capstone proof + production installer; mutations, missing/duplicate/outside pairs, decode failures and caller/stack negatives. Actual c5 lifecycle-wide orientation passed. c6 complete Position candidate inspection/negative/cap tests and read-only A-E planar math/runtime telemetry/Deinit tests pass on owned inputs. Position permission remains denied; real c6 telemetry and orientation regression require the human run.'
# c7 supersedes the historical permanent-stale policy and c6 pending result.
manifest['stop']='Hard Deinit/identity/epoch/collision/thread/provenance/integrity/kill/rollback/budget close; time-only native stale suspends and same-identity later real accepted Update resumes; no same-session hard-close recovery'
manifest['source_lifecycle_continuity'].update({'transient_stale_recovery':True,'freshness_checked_each_hot_entry_and_before_store':True,'expected_permission_epoch_pinned':True,'same_failed_session_reentry':False,'stale_states':['ACTIVE','STALE_SUSPENDED','HARD_CLOSED'],'resume_requires_later_real_Update':True,'partial_transition_recovery':'freeze last published progress; resume virtual clock, original entry/real5s cap unchanged','stale_episode_log_pair_cap':16,'stale_summary_metrics':['stale_suspend_count','stale_resume_count','max_stale_duration_ms']})
manifest['v01c6_gate']='REAL_POSITION_READ_ONLY_CONFIRMED_ORIENTATION_EARLY_EXIT_ON_TRANSIENT_250MS_UPDATE_GAP'
manifest['v01c7_gate']='SYNTHETIC_RECOVERY_PASS_REAL_LIFECYCLE_HOLD_PENDING'
manifest['real_game_lifecycle_wide_hold_verified']=False
manifest['ORIENTATION_OWNERSHIP_VERIFIED']=False
manifest['source_lifecycle_continuity']['full_WallRun_real_game_verified']=False
manifest['planar_adhesion']['real_game_telemetry_verified']=True
manifest['historical_c5_full_WallRun_hold_verified']=True
manifest['validation']='Windows warnings-as-errors; portable ASan/UBSan; Wine ABI/MinHook/source/lifecycle/compact proof tests; native real270ms gap blocks A/B and same-identity real Update resumes preserved full/partial transition through clean Deinit; stale-to-hard controls; read-only Position preserved. Synthetic c7 PASS, real-game c7 PENDING.'
manifest['limitations']=['c6 real250ms transient gap caused early source close; c7 real-game recovery/visual hold still pending','During suspension vanilla orientation can change; no promise to remove every hitch flash without human verification','A short already-admitted guarded store may finish concurrently with close/kill','Bounded diagnostic thread coverage remains incomplete; no third-path patch','Position whole-path/W/exclusive-effects proof incomplete; no Position correction/later milestone']
# c8 preserves code identity and stale recovery while diagnosing the measured c7 hard close.
manifest['v01c7_gate']='REAL_HARD_KILL_AFTER_TWO_PATH_A_WRITES_FIRST_CALLER_UNKNOWN'
manifest['v01c8_gate']='SYNTHETIC_GUARD_AND_ATTRIBUTION_PASS_REAL_ROTATION_HOLD_PENDING'
manifest['hard_kill_attribution']={'first_cause_scope':'process','immutable':True,'hot_log_deferred_to_worker':True,'lossy_ring_independent':True,'reason_and_origin_required':True,'winner_thread_context_and_native_token':True,'source_guard_subgates':True,'caller_first_difference':True,'four_patch_first_differences':True,'raw_function_bytes_logged':False,'normal_verified_Deinit':'explicit normal session close, not abnormal process kill','F8_shutdown_explicit':True,'configure_cleanup_consumes_first_cause':False,'production_reset_API':False}
manifest['observation_authentication']={'side_effect_free_detailed_status':True,'all_four_hooks_enabled_read_match':True,'patch_bytes':32,'first_difference_sentinel':32,'status_transition_log_cap':16,'verified_available_required_for_source':True,'startup_field_plan_required':True,'runtime_diagnostic_field_plan_required_for_source':False,'diagnostic_only_loss_stops_trace':True,'actual_patch_loss_kills_source':True,'input_auth_rechecked_after_tick':True,'real_c7_first_cause':'UNKNOWN_PENDING_C8_LOG'}
manifest['validation']='Windows warnings-as-errors; portable ASan/UBSan; complete Wine ABI/MinHook/source/lifecycle/compact/watch/Position suites. Real detailed status API and production worker guard tests at first0.7s interpolation distinguish diagnostic-only loss from all four actual patch mutations; immutable/racing/hot cause attribution. c7 real270ms recovery and eleven stale-hard controls retained. c8 real-game hold/first real kill cause pending.'
manifest['limitations']=['Real c7 source hard-closed after two writes; exact first caller remains unknown until c8 log','Only diagnostic field-plan runtime dependency is decoupled; all real source identities remain required','First-claim context consists of separate guarded reads; concurrent closers can affect sampled status','An already-admitted guarded store can overlap close/kill','c8 visual hold/flash/crash/Position requires human verification; Position whole-path/W/effects proof remains incomplete']
(out/'BUILD_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'logs/package_check.log').write_text(f'PASS: {label}/{version} DLL/version/README/INI; lock-free shared Path A/B orientation sources ON, direct Actor/Position/adhesion/movement/camera/animation/physics writes OFF; Path B write exactly0x24 with row scale and later metadata preserved; PE32+/2exports/systemimports/noWPM; CRC/hash/source/licenses; no private game captures/reference binaries/full dumps; actual-byte proof PASS; historical real c5 hold PASS; c6 transient-gap/c7 early hard-close regressions confirmed; c8 guard/first-cause and c7 recovery synthetic PASS, real c8 hold pending; Position remains read-only\n')
print('PASS:',package)
