#pragma once
namespace ws {
inline constexpr char versionLabel[]="v0.1c17";
inline constexpr char packageVersion[]="0.1.35";
}
