#pragma once
namespace ws {
inline constexpr char versionLabel[]="v0.1c33";
inline constexpr char packageVersion[]="0.1.51";
}
