# WallSprint development rules

## Distribution / provenance

WallSprint should remain independently implemented so it can be prepared for eventual Nexus Mods distribution.

Reference projects such as Walk On Walls, ActorRelativeCamera, SwingCore, and similar mods may be used only as research hints. Do not copy their code, binaries, assets, proprietary data, or extracted package contents into WallSprint production source or release packages.

Game-native behavior should be re-established from Spider-Man2.exe, WallSprint runtime instrumentation, and reproducible user logs wherever practical.

Do not add new vendored copies of SM2ScriptTemplate source files. Existing template dependence should eventually be reduced into WallSprint-owned minimal interop definitions after functional milestones are stable.

Release packages must not contain raw private user logs, full captured native game functions, unnecessary game binary fragments, or files from other mods.

## User-facing release naming

The user-facing install ZIP uses:

```text
MSM2-WS-v<version>.zip
```

Do not append implementation/task descriptions such as `transform_write_contract`, `callee_alias`, or `movement_source_lineage`.

A separate source archive may use:

```text
MSM2-WS-v<version>-source.zip
```

The active local Overstrike-visible script uses:

```text
MSM2-WS-v<version>.script
```

Do not append commit SHA, Git hash, GUID, random hex, or internal task names to user-facing filenames.

## Final local workspace

`docs/LOCAL_WORKSPACE.md` is authoritative for the Windows development/test layout.

The required project workspace is:

```text
<game>\Mods Library\Mods-Developing\MSM2-WS
```

with the steady-state top level:

```text
MSM2-WS-v<version>.script
Update-WS.cmd
logs\
_source\
_archive\
```

A one-time `Migrate-WS.cmd` may exist during migration.

Use hyphens in user-facing/project names (`Mods-Developing`, `MSM2-WS`, `Update-WS.cmd`). Leading underscore is reserved for internal workspace folders (`_source`, `_archive`). Do not newly create workspace aliases such as `Mods_Developing`, `MSM2_WS`, `Update_WS.cmd`, `logs_WS`, or `WS_logs`.

Reusable scripts must derive the game root from the final workspace or a validated bootstrap input; do not hard-code the user's personal C- or D-drive paths.

## One shared Overstrike / Mods Library

There is exactly one shared Overstrike for ordinary mods, MSM2-SF, and MSM2-WS:

```text
Executable:       <game>\Overstrike\Overstrike.exe
WorkingDirectory: <game>
```

Do not create project-specific Overstrike copies, AppData development copies, project-specific Mods Libraries/profiles, or `MSM2-WS\_tools\Overstrike`.

`<game>\Overstrike\winmm.dll` must not exist. Game-wide `winmm.dll` and `scripts_proxy.dll` stay in the game root and must not be duplicated into the Overstrike directory.

WallSprint update/migration tooling may validate shared infrastructure but must not treat it as WS-owned cleanup state.

## Isolation from SocialFeed and ordinary mods

WallSprint tooling must never delete, move, rename, overwrite, clean, archive, or back up anything beneath:

```text
<game>\Mods Library\Mods-Developing\MSM2-SF
```

It must likewise leave ordinary existing mods unchanged.

Only files positively identified as WallSprint-owned under `MSM2-WS` may be archived/replaced by WS cleanup/deployment logic.

## `_source` checkout invariant

The authoritative local Git checkout is:

```text
MSM2-WS\_source
```

It must be an independent clone, not a worktree/junction/symlink/reparse-point dependency on the legacy D-drive checkout.

Because Overstrike recursively scans `Mods Library`, a normal source checkout under `_source` must contain no active `*.script`. Generated script output must be produced outside recursively active source locations or use a non-`.script` temporary extension until final deployment.

Exactly one active WallSprint `.script` may exist recursively beneath `MSM2-WS`, and it must be the versioned script at workspace root. Older versions under `_archive` must use a disabled/non-active extension such as `.script.disabled`. Overstrike also discovers scripts recursively inside ZIP/RAR/7z containers without extracting them. Enforce zero visible archives beneath WS, not merely zero physical source scripts. The independent `_source` clone uses the managed non-cone sparse checkout to exclude archive extensions from its working tree; all code and tracked archive blobs/history remain in Git. Keep returned build ZIPs as `.zip.disabled`. Refuse untracked/foreign archives and custom sparse patterns rather than deleting data or overwriting configuration.

## Update / migration safety

Normal operation is `MSM2-WS\Update-WS.cmd`. It must fail closed on invalid workspace/Git/build/test/package/Overstrike prerequisites and avoid partial replacement of a known-good active script where practical.

A one-time `Migrate-WS.cmd` may create the final workspace and independent clone, but it must never automatically delete the legacy environment. Only after all required local validation passes may it state that the old WallSprint workspace can be manually removed.

Cloud Codex cannot claim the user's real C-drive migration is complete. Cloud tests use owned temporary fixtures; real Overstrike recognition and local migration remain human acceptance checks.

## Runtime logs

WallSprint runtime logs belong only under:

```text
<game>\Mods Library\Mods-Developing\MSM2-WS\logs
```

with filenames:

```text
MSM2-WS-v<version>-YYYYMMDD-HHMMSS.log
```

See `docs/LOGGING_CONVENTION.md` for failure/collision details.

## Native safety

- Current target build: Spider-Man2.exe 2.810.0.0.
- Expected SHA256: `c9b912eff96facb746a705ac8b0b83c29faa7bbe53d984a0c5eb45efd0b738c9`.
- Fail closed on build/signature mismatch.
- Do not guess typed Win64 signatures for unknown game functions.
- Preserve registers, stack alignment, shadow space, and return state when assembly thunks are required.
- Prefer narrow caller/owner/state admission over global hooks or patches.
- Never globally patch the common orientation writer solely because it is involved in WallRun/Crawl.

## Scope discipline

Work in milestones. Do not add later systems merely to mask a failure in the current one.

Current gameplay order is:

1. orientation ownership / reset path;
2. planar adhesion;
3. surface-relative movement;
4. animation integration;
5. camera;
6. jumps / wall-to-wall;
7. corners / ceilings / continuous surfaces;
8. parkour;
9. web swing;
10. combat.

Infrastructure/layout tasks do not authorize advancement to a later gameplay milestone. A failure in orientation must not be hidden by adding adhesion or movement writes.

## Documentation

Keep analysis files explicit about VERIFIED, CANDIDATE, and UNKNOWN findings. Do not upgrade a hypothesis into a verified field name or engine semantic without evidence.

When local workspace requirements change, keep `docs/LOCAL_WORKSPACE.md`, `docs/LOGGING_CONVENTION.md`, `docs/PROJECT_STATE.md`, and the relevant tests synchronized.

The supported Windows-local wrapper runs the preserved full Linux cross-build/regression chain in configured WSL2, staged outside the scanned `_source`. It must not replace that chain with a native MSVC/CMake shortcut or a prebuilt-package bypass. Root `WallSprint.script` is no longer tracked; disabled intermediates and virtual install-ZIP members preserve the one-active-script invariant. See `source/BUILD.md` for prerequisites.
